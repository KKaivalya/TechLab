    <!-- // CSS Links >>>> -->
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/panel.css?v=3.4">
    <link href="css/select2.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/ckeditor-custom.css?v=0.5">

        <!-- // Fevicon-- -->
<!--     <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png"> -->
    <link rel="icon" type="image/png" sizes="32x32" href="images/logo.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/logo.png">
    
    <!-- // Script Links >>>> -->
    <script src="js/jquery.js"></script>
    <script src="js/select2.js"></script>
    <!-- // Ckeditor & Ckfinder >>>> -->
    <script src="plugins/ckeditor5/build/ckeditor.js"></script>
    <script src="plugins/ckfinder/ckfinder.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.ui.touch-punch.min.js"></script>
    <script src="js/canvas-jquery-1.11.1.min.js"></script>
    <script src="js/jquery.canvasjs.min.js"></script>