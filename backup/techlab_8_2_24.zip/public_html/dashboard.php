<?php
// Auth
include("conf/connection.php");
include("conf/login-auth.php");
include("conf/support-auth.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tech Lab - Dashboard</title>
    <!-- // Head file >>>>> -->
    <?php include("partials/head.php"); ?>
</head>

<body>
    <div class="main-sec">
        <!-- // Sidebar file >>>> -->
        <?php include("partials/sidebar.php"); ?>
        <!-- // Content >>>> -->
        <div class="content-sec">
            <!-- --Sidebar toggle-- -->
            <img src="images/caret-right-fill.svg" alt="sidebar-menu-btn" class="sidebar-menu-btn">
            <!-- --content area-- -->
            <div class="content-area">
                <!-- // Alert area >>>> -->
                <div class="alert-area">
                    <!-- --Alerts will be here-- -->
                </div>
                <!-- // Top bar >>>> --> 
                <div class="top-bar">
                    <div class="top-bar-area">
                        <div class="top-bar-title-area">
                            <h1 class="top-bar-title font-size-medium font-weight-medium color-black">Dashboard</h1>
                            <p class="top-bar-title-desc font-size-regular font-weight-regular color-light-black">Welcome to Tech-Lab Dashboard</p>
                        </div>
                    </div>
                </div>
                <!-- // Dashboard >>>> -->
                <div class="dashboard-number-box-area">
                    <?php if($user_data["role"] == 1){ ?>
                        <div class="dashboard-number-box">
                            <div id="attendanceContainer" style="height: 300px; width: 100%;"></div>
                        </div>
                        <div class="dashboard-number-box">
                            <div id="notesContainer" style="height: 300px; width: 100%;"></div>
                        </div>
                    <?php }else if($user_data["role"] == 2){ ?>
                        <div class="dashboard-number-box">
                            <?php
                            $count_sql = $sql->prepare("SELECT COUNT(*) AS total FROM `blog_cate`");
                            $count_sql->execute();
                            $count_result = $count_sql->get_result();
                            $count = $count_result->fetch_assoc();
                            ?>
                            <img src="images/contact.svg" alt="Image" class="dashboard-number-box-img">
                            <h2 class="font-size-big font-weight-bold-color-black"><?php echo $count["total"]; ?></h2>
                            <p class="font-size-regular font-weight-regular color-light-black">Total Test Categories</p>
                        </div>
                        <div class="dashboard-number-box">
                            <?php
                            $count2_sql = $sql->prepare("SELECT COUNT(*) AS total FROM `test`");
                            $count2_sql->execute();
                            $count2_result = $count2_sql->get_result();
                            $count2 = $count2_result->fetch_assoc();
                            ?>
                            <img src="images/mobile.svg" alt="Image" class="dashboard-number-box-img">
                            <h2 class="font-size-big font-weight-bold-color-black"><?php echo $count2["total"]; ?></h2>
                            <p class="font-size-regular font-weight-regular color-light-black">Total Test</p>
                        </div>
                    <?php } ?>
                </div>
                <!-- // Contact form >>>> -->
                <!-- // Table >>>> -->
                <?php if($user_data["role"] == 1){ ?>
                    <h1 class="font-size-medium font-weight-medium color-black" style="margin-top: 50px;">Today's Entries</h1>
                <?php }else if($user_data["role"] == 2){ ?> 
                    <h1 class="font-size-medium font-weight-medium color-black" style="margin-top: 50px;">Your Test</h1>
                <?php } ?>
                <div class="table-area responsive">
                    <table class="tgpx20">
                        <thead>
                            <?php if($user_data["role"] == 1){ ?>
                            <tr>
                                <th>User Id</th>
                                <th> Name </th>
                                <th>IP</th>
                                <th>In Time</th> 
                                <th>Out Time</th>
                                <th>Total Time</th>
                                <th>Attendance Marked</th>
                                <th>Action</th>
                            </tr>
                            <?php }else if($user_data["role"] == 2){ ?>
                                <tr>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Description</th>
                                    <th>User</th>
                                    <th>Image</th>
                                    <th>Published</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            <?php } ?>
                        </thead>
                        <tbody id="entries-form-table-data-body">

                        </tbody>
                    </table>
                </div>
                <!-- // Load more >>>> -->
                <div class="loading-sec">
                    <button class="secondary-btn loading-btn" id="entries-form-loading-btn">Load more</button>
                    <div class="loading loading" id="entries-form-loading" style="display: none;">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- // Footer file >>>> -->
    <?php include("partials/footer.php"); ?>
    <script>
        $("#entries-form-loading-btn").click();
        window.onload = function () {

            var attendanceOptions = {
                subtitles: [{
                    text: "Today's Attendance"
                }],
                animationEnabled: true,
                data: [{
                    type: "pie",
                    startAngle: 270,
                    toolTipContent: "<b>{label}</b>: {y}",
                    showInLegend: "true",
                    legendText: "{label}",
                    indexLabelFontSize: 13,
                    indexLabel: "{label} - {y}",
                    dataPoints: [
                        { y: 100, label: "Attended Students"},
                        { y: 20, label: "Absent Students", exploded: true },
                    ]
                }]
            };
            var notesOptions = {
                subtitles: [{
                    text: "Notes Downloaded"
                }],
                animationEnabled: true,
                data: [{
                    type: "pie",
                    startAngle: 270,
                    toolTipContent: "<b>{label}</b>: {y}",
                    showInLegend: "true",
                    legendText: "{label}",
                    indexLabelFontSize: 13,
                    indexLabel: "{label} - {y}",
                    dataPoints: [
                        { y: 35, label: "Pending Notes"},
                        { y: 12, label: "Downloaded Notes", exploded: true },
                    ]
                }]
            };
            $("#attendanceContainer").CanvasJSChart(attendanceOptions);
            $("#notesContainer").CanvasJSChart(notesOptions);

        }
    </script>
    <script src="./js/canvas-jquery-1.11.1.min.js"></script>
    <script src="./js/jquery.canvasjs.min.js"></script>
</body>

</html>
