<?php
// Auth
include("conf/connection.php");
// include("conf/login-auth.php");
// include("conf/support-auth.php");

if (!isset($_SESSION)) {
    session_start();
}
$_SESSION["user_id"] = 1;
// To check if user already signed in
if (isset($_SESSION["user_id"])) {
    include("./conf/login-auth.php");
    if ($user_data["role"] == 1 || $user_data["role"] == 2) {
        echo '<script>location.href = "./dashboard.php"</script>';
    }else{
        echo '<script>location.href = "./permission.php"</script>';
    }
}

$error = '';
if (isset($_POST["sign_in"]) && isset($_POST['password']) && isset($_POST['email'])) {
    
    // $password = mysqli_real_escape_string($sql,$_POST['password']);
    // $email = mysqli_real_escape_string($sql,$_POST['email']);
    $email = "itsviv1433@gmail.com";
    $password = "Vivek@01";

    if (isset($_POST['cf-turnstile-response']) && !empty($_POST['cf-turnstile-response'])) {
        // reCAPTCHA response verification
        $data = [
            'secret' => "0x4AAAAAAALCPVPWRafrzX8Obdd0c_MGWXc",
            'response' => $_POST["cf-turnstile-response"],
            'remoteip' => $_SERVER['REMOTE_ADDR'],
        ];
        
        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, "https://challenges.cloudflare.com/turnstile/v0/siteverify");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        // Decode JSON data
        $response = json_decode(curl_exec($ch),true);     
        
        if ($response['success']) {
            
            $user_check_sql = $sql->prepare("SELECT * FROM users WHERE `email` = ?");
            $user_check_sql->bind_param("s", $email);
            $user_check_sql->execute();
            $user_check_result = $user_check_sql->get_result();
            if ($user_check_result->num_rows > 0) {
                $user_check = $user_check_result->fetch_assoc();
                if($user_check["status"] == "1"){
                    if (password_verify($password, $user_check["password"])) {
                        if($user_check["role"] == '1' || $user_check["role"] == '2') {
                            $_SESSION["user_id"] = $user_check["user_id"];
                            $_SESSION["role"] = $user_check["role"];
                            $_SESSION["f_name"] = $user_check["f_name"];
                            $_SESSION["enrollment_id"] = $user_check["enrollment_id"];
                            echo "<script>location.href = './dashboard.php'</script>";
                        }else{
                            echo "<script>location.href = './'</script>";
                        }
                    } else {
                        $error = "Please check your password :(";
                    }
                }else{
                    $error = "You are blocked.Please contact administrator.";
                }
            } else {
                $error = "No user found";
            }
        }else{
            $error = "You are a spammer";
        }
    }else{
        $error = "Recaptcha Failed";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Classroom - Login</title>
<!-- // Head file >>>>> -->
<?php //include("partials/head.php"); ?>

<style>
body {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    font-family: var(--font-regular);
    height: auto;
    padding: 50px;
    background: url('./images/login_bg_student.jpg');
}

h1 {
    font-weight: bold;
    margin: 0;
}

h2 {
    text-align: center;
}

p {
    font-size: 14px;
    font-weight: 100;
    line-height: 20px;
    letter-spacing: 0.5px;
    margin: 20px 0 30px;
}

span {
    font-size: 12px;
}

a {
    color: #333;
    font-size: 14px;
    text-decoration: none;
    margin: 15px 0;
}

button {
    border-radius: 20px;
    border: 1px solid #FF4B2B;
    background-color: #FF4B2B;
    color: #FFFFFF;
    font-size: 12px;
    font-weight: bold;
    padding: 12px 45px;
    letter-spacing: 1px;
    text-transform: uppercase;
    transition: transform 80ms ease-in;
}

button:active {
    transform: scale(0.95);
}

button:focus {
    outline: none;
}

button.ghost {
    background-color: transparent;
    border-color: #FFFFFF;
}

form {
    background-color: #FFFFFF;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    padding: 0 50px;
    height: 100%;
    text-align: center;
}

input {
    background-color: #eee;
    border: none;
    padding: 12px 15px;
    margin: 8px 0;
    width: 100%;
}

.container {
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 14px 28px rgba(0,0,0,0.25), 
    0 10px 10px rgba(0,0,0,0.22);
    position: relative;
    overflow: hidden;
    width: 768px;
    display: flex;
    max-width: 100%;
    min-height: 480px;
}

.form-container {
    position: absolute;
    top: 0;
    height: 100%;
    transition: all 0.6s ease-in-out;
}

.sign-in-container {
    left: 0;
    width: 50%;
    z-index: 2;
}

.container.right-panel-active .sign-in-container {
    transform: translateX(100%);
}

.sign-up-container {
    left: 0;
    width: 50%;
    opacity: 0;
    z-index: 1;
    max-height: 100%;
    overflow-y: scroll;
}

.container.right-panel-active .sign-up-container {
    transform: translateX(100%);
    opacity: 1;
    z-index: 5;
    animation: show 0.6s;
}

@keyframes show {
    0%, 49.99% {
        opacity: 0;
        z-index: 1;
    }
    
    50%, 100% {
        opacity: 1;
        z-index: 5;
    }
}

.overlay-container {
    position: absolute;
    top: 0;
    left: 50%;
    width: 50%;
    height: 100%;
    overflow: hidden;
    transition: transform 0.6s ease-in-out;
    z-index: 100;
}

.container.right-panel-active .overlay-container{
    transform: translateX(-100%);
}

.overlay {
    background: #FF416C;
    background: -webkit-linear-gradient(to right, #FF4B2B, #FF416C);
    background: linear-gradient(to right, #FF4B2B, #FF416C);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: 0 0;
    color: #FFFFFF;
    position: relative;
    left: -100%;
    height: 100%;
    width: 220%;
    transform: translateX(0);
    transition: transform 0.6s ease-in-out;
}

.container.right-panel-active .overlay {
    transform: translateX(50%);
}

.overlay-panel {
    position: absolute;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    padding: 0 40px;
    text-align: center;
    top: 0;
    height: 100%;
    width: 50%;
    transform: translateX(0);
    transition: transform 0.6s ease-in-out;
}

.overlay-left {
    transform: translateX(-20%);
}

.container.right-panel-active .overlay-left {
    transform: translateX(0);
}

.overlay-right {
    right: 0;
    transform: translateX(0);
}

.container.right-panel-active .overlay-right {
    transform: translateX(20%);
}

.social-container {
    margin: 20px 0;
}

.social-container a {
    border: 1px solid #DDDDDD;
    border-radius: 50%;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    margin: 0 5px;
    height: 40px;
    width: 40px;
}


@media screen and (max-width: 750px) {
    body {
        margin: 0;
    }
    
    .container {
        width: 100%;
        position: relative;
        flex-direction: column;
        overflow-y: scroll;
        justify-content: center;
        max-height: 70vh;
        padding: 20px;
        row-gap: 50px;
        line-height: 40px;
    }
    
    .form-container {
        width: 100%;
        position: relative;
    }
    
    .overlay-container {
        width: 100%;
        display: none;
    }
    
    .overlay {
        width: 100%;
        
    }
    
    .overlay-left,
    .overlay-right {
        width: 1-0%;
    }
    
    .overlay-panel {
        padding: 0 20px;
    }
    
    .sign-up-container{
        position: relative;
        opacity: 1;
        display: none;
    }
    
    .sign-in-container{
        position: relative;
        opacity: 1;
    }
}
</style>
</head>

<body>
<div class="main-sec">
<h2>Lab Management An Ideal Lab</h2>
<? echo $error; ?>
<div class="container" id="container">
<div class="form-container sign-up-container">
<form action="#" method="POST">
<h1>Admin Login</h1>
<!-- <span>or use your email for registration</span> -->
<input type="email" placeholder="Email" />
<input type="password" placeholder="Password" />
<div class="cf-turnstile" data-sitekey="0x4AAAAAAALCPSFk8Icu1gIy" data-callback="javascriptCallback"></div>
<button type="submit" name="sign_in">Sign In</button>
</form>
</div>
<div class="form-container sign-in-container">
<form action="#" method="POST">
<h1>Student Login</h1>
<!-- <span>or use your account</span> -->
<input type="email" placeholder="Email" />
<input type="password" placeholder="Password" />
<a href="#">Forgot your password?</a>
<div class="cf-turnstile" data-sitekey="0x4AAAAAAALCPSFk8Icu1gIy" data-callback="javascriptCallback"></div>
<button type="submit" name="sign_in">Sign In</button>
</form>
</div>
<div class="overlay-container">
<div class="overlay">
<div class="overlay-panel overlay-left">
<h1>Hello Student!</h1>
<p>To keep connected with us please login with your personal info</p>
<button class="ghost" id="signIn">Sign In</button>
</div>
<div class="overlay-panel overlay-right">
<h1>Hello, Admin!</h1>
<p>Enter your personal administrative details and start journey with us</p>
<button class="ghost" id="signUp">Sign In</button>
</div>
</div>
</div>
</div>

<!-- <footer>
<p>
Created with <i class="fa fa-heart"></i> by
<a target="_blank" href="https://florin-pop.com">Florin Pop</a>
- Read how I created this and how you can join the challenge
<a target="_blank" href="https://www.florin-pop.com/blog/2019/03/double-slider-sign-in-up-form/">here</a>.
</p>
</footer> -->

</div>
<!-- // Footer file >>>> -->
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
<?php include("partials/footer.php"); ?>
<script>
const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

signUpButton.addEventListener('click', () => {
    container.classList.add("right-panel-active");
});

signInButton.addEventListener('click', () => {
    container.classList.remove("right-panel-active");
});
</script>
</body>

</html>
